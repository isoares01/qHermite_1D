"""
Piecewise q-Hermite spline (Sections 3.3-3.5 of the article).

Supports a single global q, a different q per segment (Fig. 5b of the
article), and either prescribed derivatives or derivatives estimated
from the data.
"""
from __future__ import annotations

from typing import Optional, Sequence, Union

import numpy as np

from .basis import compute_Mq_matrix
from .mathematica_reference import qhermite_segment


class QHermiteSpline1D:
    """
    Piecewise q-Hermite interpolant through (x_i, y_i) with prescribed
    (or supplied) derivatives dy_i, following Eqs. eq:partition-eq:C1_local and
    eq:q_hermite_linear_combination-eq:complete_q_hermite_segment of the article.

    Parameters
    ----------
    x_points, y_points : array_like
        Interpolation nodes (Eq. eq:partition) and prescribed values P_i.
    dy_points : array_like, optional
        Prescribed derivatives V_i (w.r.t. x). If omitted, defaults to
        zero at every node (NOT what the article's Weierstrass benchmark
        uses -- see ``weierstrass.py`` for the term-by-term-differentiated
        derivatives actually used to reproduce Tables B.1-B.4).
    """

    def __init__(
        self,
        x_points: Sequence[float],
        y_points: Sequence[float],
        dy_points: Optional[Sequence[float]] = None,
    ):
        self.x = np.asarray(x_points, dtype=float)
        self.y = np.asarray(y_points, dtype=float)
        if self.x.ndim != 1 or len(self.x) < 2:
            raise ValueError("x_points must be a 1-D array with at least 2 nodes.")
        self.num_segments = len(self.x) - 1

        self.dy = (
            np.zeros_like(self.y) if dy_points is None else np.asarray(dy_points, dtype=float)
        )
        self._Mq_cache = {}

    def _Mq(self, q: float) -> np.ndarray:
        key = round(float(q), 12)
        if key not in self._Mq_cache:
            self._Mq_cache[key] = compute_Mq_matrix(q)
        return self._Mq_cache[key]

    def segment_coefficients(self, i: int, q: float) -> np.ndarray:
        """Return c_i = R_i @ M_q (Eq. eq:q_coefficients_matrix) for segment i and parameter q."""
        x0, x1 = self.x[i], self.x[i + 1]
        dx = x1 - x0
        R_i = np.array([self.y[i], self.y[i + 1], self.dy[i] * dx, self.dy[i + 1] * dx])
        return R_i @ self._Mq(q)

    def evaluate(self, x_eval: np.ndarray, q: Union[float, Sequence[float]]) -> np.ndarray:
        """
        Evaluate the piecewise q-Hermite interpolant at x_eval.

        Parameters
        ----------
        x_eval : array_like
            Points at which to evaluate the interpolant.
        q : float or sequence of floats
            A single global deformation parameter, or one value per
            segment (length ``self.num_segments``), reproducing the
            per-interval q selection illustrated in Fig. 5b of the
            article.
        """
        x_eval = np.asarray(x_eval, dtype=float)
        y_eval = np.full_like(x_eval, np.nan)

        if np.isscalar(q):
            q_per_segment = [float(q)] * self.num_segments
        else:
            q_per_segment = list(q)
            if len(q_per_segment) != self.num_segments:
                raise ValueError(
                    f"Expected {self.num_segments} values of q (one per segment), "
                    f"got {len(q_per_segment)}."
                )

        for i in range(self.num_segments):
            x0, x1 = self.x[i], self.x[i + 1]
            dx = x1 - x0
            last = i == self.num_segments - 1
            mask = (x_eval >= x0) & ((x_eval <= x1) if last else (x_eval < x1))
            if not np.any(mask):
                continue

            t = (x_eval[mask] - x0) / dx
            # Numerically stable, algebraically identical form of R_i M_q H_q^3(t):
            # s = h0(t) * cubic Hermite with modified data. Valid for every q in
            # (-1, 3), including q = 1 and q = 2 (removable for the interpolant).
            y_eval[mask] = qhermite_segment(t, q_per_segment[i], self.y[i], self.y[i + 1],
                                            self.dy[i] * dx, self.dy[i + 1] * dx)

        return y_eval

    def second_derivative(self, t: np.ndarray, i: int, q: float, dx: float) -> np.ndarray:
        """
        d^2 s_i^(q)/dx^2 at local parameter t in [0,1] for segment i,
        via the chain rule d^2/dx^2 = (1/dx^2) d^2/dt^2. Used by the
        oracle-free heuristics of ``heuristics.py``
        (Eqs. eq:strain_energy_criterion, eq:c2_jump_criterion).
        """
        eps = 1e-5
        t = np.atleast_1d(np.asarray(t, dtype=float))

        def s_of_t(tt):
            return qhermite_segment(tt, q, self.y[i], self.y[i + 1],
                                    self.dy[i] * dx, self.dy[i + 1] * dx)

        d2s_dt2 = (s_of_t(t + eps) - 2 * s_of_t(t) + s_of_t(t - eps)) / eps ** 2
        return d2s_dt2 / dx ** 2
