"""
qhermite
========

Open-source companion implementation for:

    Soares, I. J. A.; Costa, A. A.; Murta Junior, L. O.
    "Tsallis-Deformed Hermite Interpolation: A Parametric Family for
    Flexible Curve Modeling."

This package reproduces, symbolically and numerically, every derivation,
proposition, and numerical experiment reported in the article: the
third-degree q-Hermite basis (Eqs. eq:h0q3-eq:h3q3), the q-dependent transformation
matrix M_q (Appendix A), the linear-independence result (Proposition 1),
the classical limit q -> 1, the Weierstrass-function benchmark
(Section 5), and the boundary/complex-region illustration of
Section 4.7 ("Behavior beyond the admissible interval").

See ``README.md`` for how each article section maps to a module/example.
"""

from .basis import (
    h0_q_numeric,
    q_hermite_basis_numeric,
    compute_Mq_matrix,
    M1,
    MH_canonical,
    ADMISSIBLE_Q_MIN,
    ADMISSIBLE_Q_MAX,
    ADMISSIBLE_Q_EXCLUDED,
    is_admissible,
)
from .spline import QHermiteSpline1D
from .weierstrass import weierstrass_function, weierstrass_derivative, rmse, oracle_q_search
from .mathematica_reference import qhermite_segment, weierstrass_rational
from .benchmark import PROTOCOL, additivity, run_case

__all__ = [
    "h0_q_numeric",
    "q_hermite_basis_numeric",
    "compute_Mq_matrix",
    "M1",
    "MH_canonical",
    "ADMISSIBLE_Q_MIN",
    "ADMISSIBLE_Q_MAX",
    "ADMISSIBLE_Q_EXCLUDED",
    "is_admissible",
    "QHermiteSpline1D",
    "weierstrass_function",
    "weierstrass_derivative",
    "rmse",
    "oracle_q_search",
    "qhermite_segment",
    "weierstrass_rational",
    "PROTOCOL",
    "additivity",
    "run_case",
]

__version__ = "1.0.0"
