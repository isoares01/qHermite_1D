"""
Third-degree q-Hermite basis and transformation matrix.

Implements Eqs. eq:h0q3-eq:h3q3 and Appendix A of the article, with the basis
truncated with the "positive part" convention of Eq. eq:h0q3 (the
"+" subscript): outside the interval I_q = (-t_max(q), t_max(q)) where
4 - t^4 (q-1)^2 > 0, the basis functions are set to zero rather than
continued into the complex plane. See ``boundary.py`` and Section 3.6
of the article for why this truncation, rather than analytic
continuation, is the correct choice.

IMPORTANT CORRECTION w.r.t. the matrix at q = 1
-------------------------------------------------
The classical Hermite matrix M_H of Eq. eq:M_H,

    M_H = [[ 1, 0, -3,  2],
           [ 0, 0,  3, -2],
           [ 0, 1, -2,  1],
           [ 0, 0, -1,  1]],

is designed to combine with the *canonical monomial* basis
B_can(t) = (1, t, t^2, t^3)^T, via S(x) = R . M_H . B_can(x).

It does **not** combine correctly with the classical q-Hermite basis
H_1^3(t) = (1, t, t^2-1, t^3-3t)^T used throughout this q-deformed
construction. Combining M_H directly with H_1^3(t) does not satisfy
the prescribed Hermite restrictions -- this was a bug present in an
earlier version of the accompanying manuscript (Eqs. eq:complete_q_hermite_segment/eq:M1_matrix) and in
an earlier, now superseded, symbolic-porting script.

The correct matrix is M_1 = M_H @ A, where A is the change-of-basis
matrix satisfying B_can(t) = A . H_1^3(t):

    A = [[1, 0, 0, 0],
         [0, 1, 0, 0],
         [1, 0, 1, 0],
         [0, 3, 0, 1]]

which gives

    M_1 = [[-2,  6, -3,  2],
           [ 3, -6,  3, -2],
           [-2,  4, -2,  1],
           [-1,  3, -1,  1]].

This is confirmed, to machine precision, to equal the two-sided limit
lim_{q->1} M_q of the q != 1 appendix formula (see
``tests/test_core.py::test_M1_matches_limit_of_Mq`` and
``symbolic.py::verify_M1_is_limit_of_Mq``), so the interpolant itself
is continuous through q = 1 even though M_q and M_1 are given by
different analytic expressions.
"""
from __future__ import annotations

import numpy as np

# ---------------------------------------------------------------------------
# Admissible domain (Eq. eq:q_admissible_domain / Eq. eq:q_admissible_domain of the article)
# ---------------------------------------------------------------------------
ADMISSIBLE_Q_MIN = -1.0
ADMISSIBLE_Q_MAX = 3.0
ADMISSIBLE_Q_EXCLUDED = (1.0, 2.0)  # q = 1 handled separately; q = 2 is a
                                    # degeneracy of the basis (Proposition 2(i))


def is_admissible(q: float, eps: float = 1e-6) -> bool:
    """True if q lies in (-1, 3) and is not (numerically) 1 or 2."""
    if not (ADMISSIBLE_Q_MIN < q < ADMISSIBLE_Q_MAX):
        return False
    return all(abs(q - qx) > eps for qx in ADMISSIBLE_Q_EXCLUDED)


#: Tolerance for switching from the M_q closed form to the exact M1 at
#: q = 1. Terms in the Appendix A formulas scale like exp(C/(q-1)) with
#: C up to ~7 in absolute value; float64 overflows around exponent 1024,
#: so |q-1| must stay above roughly 7/1024 ~ 0.007 for the raw formula
#: to be safely evaluable. We use a comfortable margin above that.
Q1_SWITCH_TOL = 0.02


# ---------------------------------------------------------------------------
# Classical (q = 1) reference matrices
# ---------------------------------------------------------------------------

#: Classical Hermite matrix (Eq. eq:M_H). Combines with the canonical monomial
#: basis B_can(t) = (1, t, t^2, t^3)^T, NOT with H_1^3(t). Kept here mostly
#: for reference / cross-checking; end users should use ``M1`` below.
MH_canonical = np.array([
    [1.0, 0.0, -3.0, 2.0],
    [0.0, 0.0, 3.0, -2.0],
    [0.0, 1.0, -2.0, 1.0],
    [0.0, 0.0, -1.0, 1.0],
])

#: Change of basis matrix A such that B_can(t) = A . H_1^3(t).
_A_CHANGE_OF_BASIS = np.array([
    [1.0, 0.0, 0.0, 0.0],
    [0.0, 1.0, 0.0, 0.0],
    [1.0, 0.0, 1.0, 0.0],
    [0.0, 3.0, 0.0, 1.0],
])

#: Correct q = 1 coefficient matrix, to be combined with
#: H_1^3(t) = (1, t, t^2-1, t^3-3t)^T. See module docstring.
M1 = MH_canonical @ _A_CHANGE_OF_BASIS


# ---------------------------------------------------------------------------
# Third-degree q-Hermite basis functions (Eqs. eq:h0q3-eq:h3q3)
# ---------------------------------------------------------------------------

def h0_q_numeric(t: np.ndarray, q: float) -> np.ndarray:
    """
    Evaluate h_{0(q)}^3(t) (Eq. eq:h0q3), with the "positive part" truncation:
    the function is set to 0 wherever 4 - t^4 (q-1)^2 <= 0 (i.e. outside
    I_q), rather than continued analytically (Section 3.6).

    Switches to the exact q=1 value (1) for |q-1| < ``Q1_SWITCH_TOL``,
    since 4**(1/(q-1)) overflows float64 well before the true
    (mathematical) limit is reached; see ``compute_Mq_matrix`` for the
    analogous issue in the transformation matrix.
    """
    t = np.asarray(t, dtype=float)
    if abs(q - 1.0) < Q1_SWITCH_TOL:
        return np.ones_like(t)

    inside = 4.0 - (q - 1.0) ** 2 * t ** 4
    safe_inside = np.where(inside > 0.0, inside, 1.0)  # placeholder, masked out below
    val = (4.0 ** (1.0 / (q - 1.0))) * (safe_inside ** (1.0 / (1.0 - q)))
    return np.where(inside > 0.0, val, 0.0)


def q_hermite_basis_numeric(t: np.ndarray, q: float):
    """
    Return (h0, h1, h2, h3), the four third-degree q-Hermite basis
    functions of Eqs. eq:h0q3-eq:h3q3, evaluated at t for a given q.

    At q = 1 (within ``Q1_SWITCH_TOL``) this returns the classical basis
    {1, t, t^2 - 1, t^3 - 3t} (Eq. eq:classical_hermite_basis / Proposition "classical limit").
    """
    t = np.asarray(t, dtype=float)
    if abs(q - 1.0) < Q1_SWITCH_TOL:
        h0 = np.ones_like(t)
        h1 = t.copy()
        h2 = t ** 2 - 1.0
        h3 = t ** 3 - 3.0 * t
        return h0, h1, h2, h3

    h0 = h0_q_numeric(t, q)
    k1 = (3.0 - q) / 2.0
    k2 = (q - 3.0) * (q - 2.0) / 2.0
    k3 = 4.0 - q
    h1 = t * h0
    h2 = (k1 * t ** 2 - 1.0) * h0
    h3 = (k2 * t ** 3 - k3 * t) * h0
    return h0, h1, h2, h3


# ---------------------------------------------------------------------------
# Transformation matrix M_q (Appendix A)
# ---------------------------------------------------------------------------

def compute_Mq_matrix(q: float) -> np.ndarray:
    """
    Compute the 4x4 transformation matrix M_q mapping the Hermite
    restriction vector R_i = [P_i, P_{i+1}, V_i, V_{i+1}] to the
    coefficients c = R_i @ M_q of the local q-Hermite segment
    (Eq. eq:q_coefficients_matrix), following Appendix A of the article.

    At q = 1, returns the *corrected* matrix ``M1`` (see module
    docstring), not the classical monomial-basis matrix M_H.

    Note on numerical conditioning near q = 1
    ------------------------------------------
    Although M_q -> M_1 continuously as q -> 1 (a genuine, finite
    limit -- see the module docstring and
    ``tests/test_core.py::test_Mq_continuous_through_q1``), the
    Appendix A closed-form expressions contain terms such as
    2**(1/(q-1)), which overflow float64 already for
    |q-1| below roughly 1e-3, well before the true (mathematical)
    singularity. We therefore switch to the exact ``M1`` for
    |q-1| < ``Q1_SWITCH_TOL`` rather than waiting for a stricter
    tolerance that would silently overflow.
    """
    if abs(q - 1.0) < Q1_SWITCH_TOL:
        return M1.copy()

    if not is_admissible(q, eps=1e-3):
        raise ValueError(
            f"q={q} is outside/near the admissible domain "
            f"({ADMISSIBLE_Q_MIN}, {ADMISSIBLE_Q_MAX}) \\ {{1, 2}}; "
            "M_q is singular or numerically ill-conditioned there (Eq. eq:q_admissible_domain)."
        )

    m00 = (3.0 + q) / (q - 3.0)
    m01 = (16.0 - 4.0 * q) / ((q - 3.0) * (q - 2.0))
    m02 = 6.0 / (q - 3.0)
    m03 = 4.0 / ((q - 3.0) * (q - 2.0))

    m10 = (2.0 ** ((q - 4.0) / (q - 1.0))) * (q + 1.0) * \
          ((3.0 + 2.0 * q - q ** 2) ** (1.0 / (q - 1.0) - 2.0)) * \
          (5.0 * 2.0 ** (1.0 / (q - 1.0)) + 5.0 * 2.0 ** (q / (q - 1.0)) * q
           - 3.0 * 2.0 ** (1.0 / (q - 1.0)) * q ** 2)
    m11 = (2.0 ** (-7.0 / (q - 1.0))) * (q + 1.0) * \
          ((3.0 + 2.0 * q - q ** 2) ** (1.0 / (q - 1.0) - 2.0)) / (q - 2.0) * \
          (2.0 ** (4.0 + 5.0 / (q - 1.0)) + 15.0 * 2.0 ** (2.0 + 5.0 / (q - 1.0)) * q
           - 2.0 ** (5.0 * q / (q - 1.0)) * q ** 2 + 2.0 ** (2.0 + 5.0 / (q - 1.0)) * q ** 3)
    m12 = (2.0 ** ((q - 3.0) / (q - 1.0))) * (q + 1.0) * \
          ((3.0 + 2.0 * q - q ** 2) ** (1.0 / (q - 1.0) - 2.0)) * (5.0 + 10.0 * q - 3.0 * q ** 2)
    m13 = (2.0 ** ((2.0 * q - 4.0) / (q - 1.0))) * (q + 1.0) * \
          ((3.0 + 2.0 * q - q ** 2) ** (1.0 / (q - 1.0) - 2.0)) * \
          (1.0 + 4.0 * q - q ** 2) / (q - 2.0)

    m20 = 4.0 / (q - 3.0)
    m21 = (14.0 - 7.0 * q + q ** 2) / ((q - 3.0) * (q - 2.0))
    m22 = 4.0 / (q - 3.0)
    m23 = 2.0 / ((q - 3.0) * (q - 2.0))

    m30 = (2.0 ** ((q - 3.0) / (q - 1.0))) * ((3.0 + 2.0 * q - q ** 2) ** (1.0 / (q - 1.0))) / (q - 3.0)
    m31 = (2.0 ** ((q - 3.0) / (q - 1.0))) * (q - 4.0) * \
          ((3.0 + 2.0 * q - q ** 2) ** (q / (q - 1.0))) / \
          (((q - 3.0) ** 2) * (q - 2.0) * (q + 1.0))
    m32 = (2.0 ** ((q - 3.0) / (q - 1.0))) * ((3.0 + 2.0 * q - q ** 2) ** (1.0 / (q - 1.0))) / (q - 3.0)
    m33 = (2.0 ** ((q - 3.0) / (q - 1.0))) * ((3.0 + 2.0 * q - q ** 2) ** (1.0 / (q - 1.0))) / ((q - 3.0) * (q - 2.0))

    return np.array([
        [m00, m01, m02, m03],
        [m10, m11, m12, m13],
        [m20, m21, m22, m23],
        [m30, m31, m32, m33],
    ])
