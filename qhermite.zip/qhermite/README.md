# qhermite — Tsallis-deformed (q-Hermite) interpolation

Companion code for the article

> I. J. A. Soares, A. A. Costa, L. O. Murta Junior.
> **Tsallis-Deformed Hermite Interpolation: A Parametric Family for Flexible Curve Modeling.**
> *Computer Aided Geometric Design* (submitted). `<PAPER_LINK>`

The package implements the third-degree q-Hermite basis obtained from a
q-deformed Rodrigues formula, the piecewise q-Hermite interpolant (one global
`q` or one `q` per segment), symbolic checks of every formula in the article,
and the scripts that regenerate **all tables, the RMSE figures and every number
quoted in Section 4**.

---

## 1. Install

```bash
git clone https://github.com/isoares01/qHermite_1D
cd qHermite_1D
python -m pip install -e ".[all]"      # numpy, scipy, sympy, matplotlib, pytest
python -m pytest -q                    # 133 tests, ~30 s
```

Python >= 3.9. Without `matplotlib` everything runs except the figures.

## 2. Five-minute tour

```python
import numpy as np
from qhermite import QHermiteSpline1D, qhermite_segment, additivity

# one segment on t in [0, 1]: s(0)=P0, s(1)=P1, s'(0)=V0, s'(1)=V1
t = np.linspace(0, 1, 5)
qhermite_segment(t, q=1.0, P0=0.1, P1=0.3)     # classical cubic Hermite
qhermite_segment(t, q=2.9, P0=0.1, P1=0.3)     # super-additive deformation

# zero tangents: s(1/2) = alpha*P0 + beta*P1, alpha+beta = 1 only for q = 1
additivity(2.9)    # -> (0.5155, 0.8890, 1.4045)

# piecewise interpolant; tangents dy are free parameters (default: zero)
x = np.linspace(0, 1, 7); y = np.sin(3 * x)
s = QHermiteSpline1D(x, y)
s.evaluate(np.linspace(0, 1, 50), q=2.6)                       # global q
s.evaluate(np.linspace(0, 1, 50), q=[2.9, 1.4, -0.2, 2.8, 2.1, -0.5])  # one q per segment
```

Admissible range: `-1 < q < 3`. `q = 1` (classical) and `q = 2` are
**removable** for the interpolant (article, Proposition 2(ii)); only `q = -1` and
`q = 3` are genuine singularities.

## 3. Examples (run in order)

| # | Script | What it shows | Article |
|---|---|---|---|
| 01 | `examples/01_basis_functions.py` | the four q-Hermite basis functions for several `q` | Fig. 1 |
| 02 | `examples/02_single_segment_additivity.py` | super/sub-additivity, non-reproduction of constants | Corollary 1, Fig. 4 |
| 03 | `examples/03_piecewise_interpolation.py` | global vs per-segment `q` on `W_3` | Fig. 5 |
| 04 | `examples/04_reproduce_article.py` | Tables B.1-B.4, Fig. 6, numbers of Section 4 + confrontation report | Section 4, App. B |
| 05 | `examples/05_replicate_2013_notebook.py` | bit-for-bit replica of the original Mathematica run | Code availability |
| 06 | `examples/06_beyond_admissible_domain.py` | complex/branch-point behaviour outside `(-1, 3)` | Section 3.6 |

Outputs go to `examples/outputs/`.

## 4. Reproducing the article

```bash
python -m qhermite.article --outdir <article directory>
```

writes `tables/tab_W{2,3,4,5}.tex` (input by the LaTeX source),
`results/macros.tex` (every number in the text), `results/results.csv`,
`results/report.txt`, `figuras/Weierstrass_{a}_rmse.pdf` (Fig. 6) and
`figuras/fig1_*..fig5*.pdf` (Figs. 1-5, from the data of the original
Mathematica notebooks; `qhermite/figures.py`), and prints a
plain-text report comparing each row with the previously published values and
with the original 2013 computation. The protocol (zero tangents, errors at the
2x-upsampled points, standard RMSE, `q` grid `-0.80:0.01:2.90`, classical
reference at `q = 1`) is described in [`docs/02_protocol.md`](docs/02_protocol.md).

## 5. Repository map

```
qhermite/
  basis.py                  q-Hermite basis h0..h3, closed-form matrix M_q (Appendix A), M_1
  mathematica_reference.py  stable segment formula s = h0 * p; replica of the 2013 notebook
  spline.py                 QHermiteSpline1D (global or per-segment q)
  benchmark.py              article protocol (PROTOCOL dict), additivity weights
  article.py                generates tables / macros / figures / report
  figures.py                Figs. 1-5 of the article (original notebook data)
  symbolic.py               SymPy re-derivation of the basis, M_q, Proposition 2(i), q -> 1
  boundary.py               behaviour beyond the admissible domain (Section 3.6)
  heuristics.py             oracle-free q selection (strain energy -- degenerate -- and C2 jump)
  weierstrass.py            W_a(x) helpers, RMSE, generic oracle search
tests/                      pytest suite (one test per claim)
examples/                   numbered, didactic scripts (see table above)
docs/                       theory summary, protocol, article-to-code map, history
reference/mathematica/      original 2013 Mathematica notebook (Tables 1-4)
```

## 6. Documentation

1. [`docs/01_theory.md`](docs/01_theory.md) — the construction in one page
2. [`docs/02_protocol.md`](docs/02_protocol.md) — numerical protocol of Section 4
3. [`docs/03_article_map.md`](docs/03_article_map.md) — every equation/table/figure → code → test
4. [`docs/04_history.md`](docs/04_history.md) — alignment with the 2013 notebook and corrections

Equation references in docstrings use the LaTeX labels of the article
(e.g. `eq:h0q3`), which are stable across revisions.

## 7. Citing

See [`CITATION.cff`](CITATION.cff). License: MIT ([`LICENSE`](LICENSE)).
