# 3. Article → code → test

| Article | Code | Test |
|---|---|---|
| q-exponential, modified operator `D_qR` (Sec. 3) | `symbolic.derive_q_hermite_basis` | `python -m qhermite.symbolic` |
| Basis `h0..h3` (`eq:h0q3`–`eq:h3q3`) | `basis.q_hermite_basis_numeric` | `test_core.py` |
| Proposition 1 (linear independence) | `symbolic.verify_proposition_1` | `python -m qhermite.symbolic` |
| Proposition 2 (factorization, removable `q = 1, 2`) | `mathematica_reference.qhermite_segment` | `test_mathematica_reference.py::test_stable_segment_equals_appendix_matrix_form`, `::test_removable_at_q1_and_q2` |
| Corollary 1 (additivity) | `benchmark.additivity` | `test_benchmark.py::test_additivity_sign` |
| Classical limit, `M_1 = M_H A` | `basis.M1`, `symbolic.verify_M1_correction` | `test_core.py` |
| Appendix A (`M_q`) | `basis.compute_Mq_matrix` | `symbolic.verify_Mq_matches_appendix` |
| Sec. 4.7 (beyond `(-1, 3)`) | `boundary.py` | `test_core.py` |
| Tables 1-4, Figs. 7-10, numbers of Sec. 5 | `article.py`, `benchmark.py` | `test_benchmark.py` |
| Sec. 5.4 (strain energy always selects `q = 1`) | `heuristics.select_q_strain_energy` | `test_benchmark.py::test_strain_energy_criterion_selects_classical` |
| Original 2013 run | `mathematica_reference.py`, `reference/mathematica/` | `test_mathematica_reference.py` (32 rows) |
| Figs. 1, 4, 5 | `examples/01`, `02`, `03` | — |
