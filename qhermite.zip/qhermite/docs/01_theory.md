# 1. The construction in one page

**q-exponential and modified Rodrigues operator.**
`exp_q(x) = [1 + (1-q) x]^(1/(1-q))`. The basis uses the operator
`D_qR f(t) = [1 - (1-q) t^2/2] f'(t)`, iterated literally, applied to
`exp_q(-t^2/2)`:

    h_n^(q)(t) = (-1)^n exp_q(t^2/2) (D_qR)^n [exp_q(-t^2/2)]

**Third-degree basis** (`qhermite.basis.q_hermite_basis_numeric`,
checked symbolically in `qhermite.symbolic`):

    h0 = [1 - (q-1)^2 t^4 / 4]^(1/(1-q))
    h1 = t h0,   h2 = (k1 t^2 - 1) h0,   h3 = (k2 t^3 - k3 t) h0
    k1 = (3-q)/2,  k2 = (q-3)(q-2)/2,  k3 = 4-q

Linearly independent for `q != 2, 3` (Proposition 1); classical basis
`{1, t, t^2-1, t^3-3t}` at `q = 1`.

**Factorized interpolant** (Proposition 2, `qhermite.qhermite_segment`).
With `a = h0(1)` and `b = h0'(1)`, the segment satisfying
`s(0)=P0, s(1)=P1, s'(0)=V0, s'(1)=V1` is

    s(t) = h0(t) * p(t),
    p = classical cubic Hermite with data (P0, P1/a, V0, (V1 - b P1/a)/a).

Consequences: continuous in `q` on `(-1, 3)`; `q = 1` and `q = 2` removable;
numerically stable (this is the form the package evaluates). The closed-form
matrix `M_q` of Appendix A (`qhermite.basis.compute_Mq_matrix`) gives the same
curve and is kept for reference.

**Additivity** (Corollary 1, `qhermite.additivity`). With zero tangents,
`s(t) = alpha_q(t) P0 + beta_q(t) P1`; `alpha_q + beta_q = 1` only for `q = 1`.
At the midpoint, `alpha+beta > 1` for `q > 1` (super-additive) and `< 1` for
`q < 1` (sub-additive). Hence, for `q != 1`: constants are not reproduced, the
preferred `q` depends on the zero level of the data, and the error of a fixed
`q` does not vanish under refinement.
