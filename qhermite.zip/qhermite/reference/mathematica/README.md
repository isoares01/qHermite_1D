# Original Mathematica notebook (2013)

`1DTensorBSplines_Clean_2013-03_tabelas.nb` — Mathematica notebook (last saved
2013-03-26) whose stored `Print` outputs contain every number of the first
version of Tables 1-4. Kept for provenance; its Python replica is
`qhermite/mathematica_reference.py`. See `docs/04_history.md` for the
differences with the protocol of the published article.

Key cells: `QHermite3n` (basis), `Coeficientes`/`Pesos` (coefficients from the
four Hermite conditions), `SNQ` (piecewise evaluation), `RMSE`, and the
"VERSÃO 'MULTI' 2" sections (q scan for `k0 = 2, 3, 4, 5`).
