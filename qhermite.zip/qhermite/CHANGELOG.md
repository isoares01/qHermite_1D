# Changelog

## 1.0.0 — version accompanying the submitted article
- Article protocol (`benchmark.py`) and single source of truth for tables, figures and numbers (`article.py`).
- Stable factorized evaluation `s = h0 * p` (`qhermite_segment`); `q = 1` and `q = 2` removable.
- Additivity weights (`additivity`); strain-energy criterion documented as degenerate.
- Replica of the original 2013 Mathematica run (`mathematica_reference.py`) and the notebook itself.
- Corrected classical matrix `M_1 = M_H A`.
- Numbered didactic examples and `docs/`.
